﻿"""
C题 问题1 风化关联分析——卡方检验完整代码
功能：分析玻璃类型、纹饰、颜色与风化状态的关联性
输出：列联表、卡方检验结果、Cramer's V、可视化图表（方案B：低饱和蓝绿配色，学术期刊通用）
"""
import pandas as pd
import numpy as np
from scipy.stats import chi2_contingency, fisher_exact
import matplotlib.pyplot as plt
from statsmodels.graphics.mosaicplot import mosaic
import warnings
warnings.filterwarnings('ignore')

# 设置中文字体（解决图表中文显示问题）
plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

# ====================== 1. 数据读取与预处理 ======================
print("="*60)
print("1. 数据读取与预处理")
print("="*60)

# 读取表单1（使用openpyxl引擎，适配新版Excel）
form1 = pd.read_excel('附件_20260731211954.xlsx', sheet_name='表单1', engine='openpyxl')

# 按文物编号去重，每件文物只保留一条记录（避免重复统计）
df_weather = form1.drop_duplicates(subset=['文物编号']).copy()
print(f"全部文物样本总量：{len(df_weather)} 件")

# 颜色有效样本：剔除颜色为空的样本（共4件，编号19、40、48、58）
df_color_valid = df_weather[df_weather['颜色'].notna()].copy()
missing_ids = df_weather[df_weather['颜色'].isna()]['文物编号'].tolist()
print(f"剔除颜色缺失后有效样本量：{len(df_color_valid)} 件")
print(f"颜色缺失样本编号：{missing_ids}")

# ====================== 2. 定义工具函数 ======================
print("\n" + "="*60)
print("2. 执行卡方检验")
print("="*60)

def cramers_v(chi2, n, r, c):
    """计算Cramer's V关联强度系数（量化关联大小）"""
    min_dim = min(r - 1, c - 1)
    if min_dim == 0:
        return 0.0
    return np.sqrt(chi2 / (n * min_dim))

def check_expected_freq(exp_table):
    """检查理论频数是否满足卡方检验条件（>80%单元格≥5）"""
    total = exp_table.size
    less5 = (exp_table < 5).sum()
    ratio = less5 / total
    print(f"  理论频数<5的单元格：{less5}/{total}，占比{ratio:.1%}")
    if ratio > 0.2:
        print("  ⚠️ 超过20%单元格理论频数不足，建议合并低频类别或使用Fisher精确检验")
    return ratio

def run_chi2_test(contingency_table, name, n_total):
    """执行卡方检验并输出完整结果（列联表+统计量+结论）"""
    print(f"\n--- {name} ---")
    print("列联表：")
    print(contingency_table)
    
    # 核心卡方检验计算
    chi2, p, dof, expected = chi2_contingency(contingency_table)
    check_expected_freq(expected)
    
    # 计算关联强度与等级
    r, c = contingency_table.shape
    v = cramers_v(chi2, n_total, r, c)
    if v < 0.1:
        strength = "微弱"
    elif v < 0.3:
        strength = "弱"
    elif v < 0.5:
        strength = "中等"
    else:
        strength = "强"
    
    # 输出统计结果
    print(f"  卡方值 χ² = {chi2:.4f}")
    print(f"  自由度 df = {dof}")
    print(f"  p值 = {p:.6f}")
    print(f"  Cramer's V = {v:.4f} ({strength}关联)")
    
    # 2×2表理论频数不足时，补充Fisher精确检验
    if r == 2 and c == 2 and (expected < 5).any():
        odds, p_fisher = fisher_exact(contingency_table)
        print(f"  ⚠️ 理论频数不足，Fisher精确检验 p值 = {p_fisher:.6f}")
    
    # 显著性结论（α=0.05）
    if p < 0.05:
        print(f"  结论：p < 0.05，拒绝H₀，{name}与风化存在显著关联")
    else:
        print(f"  结论：p ≥ 0.05，无法拒绝H₀，{name}与风化无显著关联")
    
    return {'chi2': chi2, 'p': p, 'dof': dof, 'v': v, 'strength': strength}

# ====================== 3. 分类变量-风化关联检验 ======================
# 3.1 玻璃类型 × 风化（2×2列联表）
ct_type = pd.crosstab(df_weather['类型'], df_weather['表面风化'])
result_type = run_chi2_test(ct_type, "玻璃类型 × 风化", len(df_weather))

# 3.2 纹饰 × 风化（3×2列联表）
ct_orn = pd.crosstab(df_weather['纹饰'], df_weather['表面风化'])
result_orn = run_chi2_test(ct_orn, "纹饰 × 风化", len(df_weather))

# 3.3 颜色 × 风化（8×2列联表，已剔除缺失）
ct_color = pd.crosstab(df_color_valid['颜色'], df_color_valid['表面风化'])
result_color = run_chi2_test(ct_color, "玻璃颜色 × 风化", len(df_color_valid))

# ====================== 4. 结果汇总表（论文三线表格式） ======================
print("\n" + "="*60)
print("3. 结果汇总（论文三线表格式）")
print("="*60)

summary_df = pd.DataFrame({
    '关联变量': ['玻璃类型-风化', '纹饰-风化', '玻璃颜色-风化'],
    '有效样本量': [len(df_weather), len(df_weather), len(df_color_valid)],
    'χ²': [round(result_type['chi2'], 4), round(result_orn['chi2'], 4), round(result_color['chi2'], 4)],
    '自由度(df)': [result_type['dof'], result_orn['dof'], result_color['dof']],
    'p值': [round(result_type['p'], 6), round(result_orn['p'], 6), round(result_color['p'], 6)],
    "Cramer's V": [round(result_type['v'], 4), round(result_orn['v'], 4), round(result_color['v'], 4)],
    '关联强度': [result_type['strength'], result_orn['strength'], result_color['strength']]
})

print(summary_df.to_string(index=False))

# ====================== 5. 可视化图表（方案B：低饱和蓝绿配色） ======================
print("\n" + "="*60)
print("4. 生成可视化图表")
print("="*60)

# 提前计算核心数据（避免变量未定义）
# 颜色-风化率（转百分比，保留2位小数）
color_rates = ct_color['风化'] / ct_color.sum(axis=1)  # 原始比例
color_rates_pct = color_rates * 100  # 转百分比
color_rates_sorted = color_rates_pct.sort_values(ascending=False)  # 降序排列
avg_rate_pct = color_rates_pct.mean()  # 平均风化率

# 【方案B配色定义】低饱和蓝绿，学术期刊通用
COLOR_WEATHERED = '#2980B9'  # 风化：低饱和深蓝
COLOR_UNWEATHERED = '#27AE60'  # 无风化：灰调薄荷绿
GRADIENT_HIGH = '#2C3E50'  # 高风化渐变：深灰蓝
GRADIENT_MID = '#5D7FA6'    # 中风化渐变：中蓝
GRADIENT_LOW = '#94B3D9'    # 低风化渐变：浅灰蓝

# 5.1 堆叠百分比柱状图（方案B配色）
fig1, ax1 = plt.subplots(figsize=(10, 6))
# 计算占比并绘图
ct_percent = ct_color.div(ct_color.sum(axis=1), axis=0) * 100
ct_percent.plot(
    kind='bar', 
    stacked=True, 
    ax=ax1, 
    color=[COLOR_WEATHERED, COLOR_UNWEATHERED],  # 方案B核心配色
    edgecolor='#333333',  # 细黑边框，增强立体感
    linewidth=0.8
)
# 图表美化
ax1.set_title('不同颜色玻璃的风化/无风化占比分布', fontsize=14, fontweight='bold', pad=15)
ax1.set_ylabel('样本占比 (%)', fontsize=12)
ax1.set_xlabel('玻璃颜色', fontsize=12)
ax1.legend(title='风化状态', labels=['风化', '无风化'], loc='upper right', frameon=True, fancybox=True, shadow=False)
ax1.axhline(y=50, color='gray', linestyle='--', alpha=0.3)  # 50%参考线，弱化不抢主体
ax1.grid(axis='y', linestyle='--', alpha=0.2, linewidth=0.8)  # 浅灰网格线
ax1.set_axisbelow(True)  # 网格线置于柱子下方
plt.xticks(rotation=45, ha='right', fontsize=10)  # X轴标签倾斜，避免重叠
plt.tight_layout()  # 自动调整布局，防止标签截断
plt.savefig('颜色_风化_堆叠柱状图.png', dpi=300, bbox_inches='tight')  # 300dpi高清，适配印刷
print("已保存：颜色_风化_堆叠柱状图.png")

# 5.2 专业版风化率柱状图（方案B渐变配色）
fig2, ax2 = plt.subplots(figsize=(10, 6))
# 低饱和蓝渐变配色（方案B），替代刺眼高饱和色
colors = []
for val in color_rates_sorted.values:
    if val >= 0.8:
        colors.append(GRADIENT_HIGH)  # 高风化：深灰蓝
    elif val >= 0.4:
        colors.append(GRADIENT_MID)   # 中风化：中蓝
    else:
        colors.append(GRADIENT_LOW)   # 低风化：浅灰蓝
# 绘制柱状图
bars = ax2.bar(
    color_rates_sorted.index,
    color_rates_sorted.values,
    color=colors,
    edgecolor='#333333',
    linewidth=1.2,
    alpha=0.9  # 轻微透明，避免厚重感
)
# 柱子顶部数值标签（贴近柱子，不悬空）
for bar in bars:
    height = bar.get_height()
    ax2.text(
        bar.get_x() + bar.get_width()/2.,
        height + 0.02,  # 仅高于柱子0.02，避免悬空
        f'{height:.2f}%',  # 显示2位小数，区分细微差异
        ha='center', va='bottom',
        fontsize=10, fontweight='bold'
    )
# 图表美化
ax2.set_title('不同颜色玻璃的风化率对比', fontsize=14, fontweight='bold', pad=15)
ax2.set_ylabel('风化率 (%)', fontsize=12)
ax2.set_xlabel('玻璃颜色', fontsize=12)
# Y轴自适应（关键！柱子自动放大，不用固定0-80，低风化率也清晰）
ax2.set_ylim(0, max(color_rates_sorted.values) * 1.3)
ax2.grid(axis='y', linestyle='--', alpha=0.2, linewidth=0.8)
ax2.set_axisbelow(True)
# X轴标签倾斜30°，避免重叠
ax2.set_xticks(range(len(color_rates_sorted.index)))
ax2.set_xticklabels(color_rates_sorted.index, fontsize=10, rotation=30, ha='right')
# 平均风化率参考线（与高风化渐变同色系，保持统一）
ax2.axhline(y=avg_rate_pct, color=GRADIENT_HIGH, linestyle='-.', linewidth=1.2, alpha=0.8)
ax2.text(
    len(color_rates_sorted.index)-0.5,
    avg_rate_pct + 0.03,
    f'平均风化率: {avg_rate_pct:.2f}%',
    fontsize=9, color=GRADIENT_HIGH, ha='right'
)
# 极简边框（仅保留左下，学术图表简洁风格）
ax2.spines['top'].set_visible(False)
ax2.spines['right'].set_visible(False)
ax2.spines['left'].set_linewidth(1)
ax2.spines['bottom'].set_linewidth(1)
plt.tight_layout()
plt.savefig('各颜色风化率对比_论文版.png', dpi=300, bbox_inches='tight')
print("已保存：各颜色风化率对比_论文版.png")

# 5.3 马赛克图（方案B配色统一，删除无效edgecolor/linewidth参数）
fig3, ax3 = plt.subplots(figsize=(11, 6))
mosaic(
    df_color_valid, 
    ['颜色', '表面风化'], 
    ax=ax3,
    title='玻璃颜色与风化状态马赛克图',
    labelizer=lambda k: f'{k[0]}\n({k[1]})',
    properties=lambda x: {'facecolor': COLOR_WEATHERED if x[1] == '风化' else COLOR_UNWEATHERED}
)
ax3.set_title('玻璃颜色与风化状态马赛克图', fontsize=14, fontweight='bold', pad=15)
plt.xticks(rotation=45, ha='right', fontsize=10)
plt.tight_layout()
plt.savefig('颜色_风化_马赛克图.png', dpi=300, bbox_inches='tight')
print("已保存：颜色_风化_马赛克图.png")

# 统一显示所有图表
plt.show()

# ====================== 6. 输出列联表原始数据（供论文直接使用） ======================
print("\n" + "="*60)
print("5. 列联表原始数据（可直接复制到论文表格）")
print("="*60)

print("\n【玻璃类型 × 风化】")
print(ct_type.to_markdown())

print("\n【纹饰 × 风化】")
print(ct_orn.to_markdown())

print("\n【颜色 × 风化】（有效样本54件，剔除4件颜色缺失）")
print(ct_color.to_markdown())

# ====================== 7. 保存结果到Excel（便于后续分析） ======================
with pd.ExcelWriter('风化关联分析结果.xlsx') as writer:
    ct_type.to_excel(writer, sheet_name='类型×风化列联表')
    ct_orn.to_excel(writer, sheet_name='纹饰×风化列联表')
    ct_color.to_excel(writer, sheet_name='颜色×风化列联表')
    summary_df.to_excel(writer, sheet_name='结果汇总', index=False)

print("\n结果已保存至：风化关联分析结果.xlsx")
print("\n" + "="*60)
print("分析完成！")
print("="*60)