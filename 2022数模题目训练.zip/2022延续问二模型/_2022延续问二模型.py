﻿"""
问题3：未知玻璃文物类型鉴别
- 加载问题2训练好的模型和标准化器
- 对表单3的8个未知样本进行预测
- 输出分类结果和预测概率
- 敏感性分析（阈值 + 特征扰动）
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
import xgboost as xgb
import warnings
warnings.filterwarnings('ignore')

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

# ====================== 1. 加载数据 ======================
print("=" * 70)
print("问题3：未知玻璃文物类型鉴别")
print("=" * 70)

# 加载预处理后的未知样本
df_unknown = pd.read_csv('form3_unknown_preprocessed.csv')

# 加载问题2中使用的特征列
component_cols = ['二氧化硅(SiO2)', '氧化钠(Na2O)', '氧化钾(K2O)', '氧化钙(CaO)',
                  '氧化镁(MgO)', '氧化铝(Al2O3)', '氧化铁(Fe2O3)', '氧化铜(CuO)',
                  '氧化铅(PbO)', '氧化钡(BaO)', '五氧化二磷(P2O5)', '氧化锶(SrO)',
                  '氧化锡(SnO2)', '二氧化硫(SO2)']

ratio_cols = ['PbO_BaO_ratio', 'K2O_SiO2_ratio', 'flux_network_ratio']
feature_cols = component_cols + ratio_cols

print(f"\\n未知样本数量：{len(df_unknown)} 条")
print(f"未知样本编号：{df_unknown['文物编号'].tolist()}")

# ====================== 2. 准备特征 ======================
X_unknown = df_unknown[feature_cols].copy()
print(f"\\n未知样本缺失值数量：{X_unknown.isnull().sum().sum()}")

# ====================== 3. 加载标准化器和模型 ======================
try:
    import joblib
    scaler = joblib.load('scaler.pkl')
    model = joblib.load('xgb_model.pkl')
    print("\\n已加载保存的标准化器和模型")
except:
    print("\\n未找到保存的模型，正在重新训练...")
    
    df_train = pd.read_csv('df_all_preprocessed.csv')
    df_class = df_train[df_train['风化等级'].isin([0, 1])].copy()
    
    X_train_all = df_class[feature_cols].copy()
    y_train_all = df_class['类型_编码'].copy()
    
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train_all)
    
    scale_pos_weight = (y_train_all == 0).sum() / (y_train_all == 1).sum()
    model = xgb.XGBClassifier(
        n_estimators=100,
        max_depth=4,
        learning_rate=0.1,
        scale_pos_weight=scale_pos_weight,
        random_state=42,
        use_label_encoder=False,
        eval_metric='logloss'
    )
    model.fit(X_train_scaled, y_train_all)
    
    try:
        import joblib
        joblib.dump(scaler, 'scaler.pkl')
        joblib.dump(model, 'xgb_model.pkl')
        print("模型已保存")
    except:
        print("无法保存模型，将在内存中使用")

# ====================== 4. 预测未知样本 ======================
print("\\n" + "=" * 70)
print("预测未知样本")
print("=" * 70)

X_unknown_scaled = scaler.transform(X_unknown)
y_pred = model.predict(X_unknown_scaled)
y_prob = model.predict_proba(X_unknown_scaled)

results = df_unknown[['文物编号', '表面风化']].copy()
results['预测类型编码'] = y_pred
# 【修复】numpy数组用np.where
results['预测类型'] = np.where(y_pred == 0, '高钾', '铅钡')
results['高钾概率'] = y_prob[:, 0]
results['铅钡概率'] = y_prob[:, 1]

print("\\n【预测结果】")
print(results[['文物编号', '表面风化', '预测类型', '高钾概率', '铅钡概率']].to_string(index=False))

# ====================== 5. 详细结果输出 ======================
print("\\n" + "=" * 70)
print("详细预测结果")
print("=" * 70)

for _, row in results.iterrows():
    print(f"\\n文物 {row['文物编号']}（{row['表面风化']}）：")
    print(f"  预测类型：{row['预测类型']}")
    print(f"  高钾概率：{row['高钾概率']:.4f}")
    print(f"  铅钡概率：{row['铅钡概率']:.4f}")
    confidence = max(row['高钾概率'], row['铅钡概率'])
    if confidence > 0.9:
        level = "高置信度"
    elif confidence > 0.7:
        level = "中等置信度"
    else:
        level = "低置信度（建议人工复核）"
    print(f"  置信度：{level}")

# ====================== 6. 保存结果 ======================
results.to_csv('问题3_未知样本预测结果.csv', index=False, encoding='utf-8-sig')
print("\\n预测结果已保存至：问题3_未知样本预测结果.csv")

# ====================== 7. 敏感性分析 ======================
print("\\n" + "=" * 70)
print("敏感性分析")
print("=" * 70)

# ====================== 7.1 概率阈值敏感性 ======================
print("\\n【概率阈值敏感性】")
thresholds = [0.3, 0.4, 0.5, 0.6, 0.7]
temp_df = results[['文物编号', '预测类型', '铅钡概率']].copy()

for thresh in thresholds:
    # 【修复】用np.where替代map
    temp_df[f'阈值{thresh}预测'] = np.where(temp_df['铅钡概率'] >= thresh, '铅钡', '高钾')

print(temp_df.to_string(index=False))

unstable_id = []
for idx, row in temp_df.iterrows():
    col_list = [f'阈值{t}预测' for t in thresholds]
    all_pred = row[col_list].unique()
    if len(all_pred) > 1:
        unstable_id.append(row['文物编号'])

if len(unstable_id) > 0:
    print(f"\\n阈值0.3~0.7区间内分类不稳定文物：{unstable_id}")
else:
    print("\\n阈值0.3~0.7区间内所有样本分类结果完全稳定")

# ====================== 7.2 特征扰动敏感性 ======================
print("\\n【特征扰动敏感性】")
pb_col = '氧化铅(PbO)'
pb_idx = feature_cols.index(pb_col)

for sample_idx in range(len(X_unknown)):
    original_pb = X_unknown.iloc[sample_idx, pb_idx]
    original_pred = results.iloc[sample_idx]['预测类型']
    id_name = results.iloc[sample_idx]['文物编号']
    
    print(f"\\n  文物 {id_name} (原始PbO={original_pb:.2f}%，原始预测={original_pred}):")
    
    if original_pred == "高钾":
        perturb_list = [0.05, 0.1, 0.15, 0.2]
        for perturb in perturb_list:
            new_pb = original_pb + perturb * 10
            X_perturb = X_unknown.iloc[sample_idx:sample_idx+1].copy()
            X_perturb.iloc[0, pb_idx] = new_pb
            X_perturb_scaled = scaler.transform(X_perturb)
            pred_perturb = model.predict(X_perturb_scaled)[0]
            pred_type = '高钾' if pred_perturb == 0 else '铅钡'
            mark = "!!类别翻转" if pred_type != original_pred else "稳定"
            print(f"    PbO增加{perturb*10:.1f}% → {new_pb:.2f}% → {pred_type}，{mark}")
    else:
        perturb_list = [-0.1, -0.05, 0.05, 0.1]
        for perturb in perturb_list:
            new_pb = original_pb * (1 + perturb)
            new_pb = max(new_pb, 0)
            X_perturb = X_unknown.iloc[sample_idx:sample_idx+1].copy()
            X_perturb.iloc[0, pb_idx] = new_pb
            X_perturb_scaled = scaler.transform(X_perturb)
            pred_perturb = model.predict(X_perturb_scaled)[0]
            pred_type = '高钾' if pred_perturb == 0 else '铅钡'
            mark = "!!类别翻转" if pred_type != original_pred else "稳定"
            print(f"    PbO {perturb*100:+.0f}% → {new_pb:.2f}% → {pred_type}，{mark}")

# ====================== 8. 可视化 ======================
print("\\n" + "=" * 70)
print("生成可视化图表")
print("=" * 70)

# 8.1 各未知样本分类概率柱状图
fig, ax = plt.subplots(figsize=(12, 6))
x = np.arange(len(results))
width = 0.35
bars1 = ax.bar(x - width/2, results['高钾概率'], width, label='高钾概率', color='#638bd6', edgecolor='black')
bars2 = ax.bar(x + width/2, results['铅钡概率'], width, label='铅钡概率', color='#e67e22', edgecolor='black')

for bar in bars1:
    height = bar.get_height()
    ax.text(bar.get_x() + bar.get_width()/2., height + 0.02,
            f'{height:.2f}', ha='center', va='bottom', fontsize=9)
for bar in bars2:
    height = bar.get_height()
    ax.text(bar.get_x() + bar.get_width()/2., height + 0.02,
            f'{height:.2f}', ha='center', va='bottom', fontsize=9)

ax.set_xticks(x)
ax.set_xticklabels(results['文物编号'], fontsize=11)
ax.set_xlabel("文物编号", fontsize=12)
ax.set_ylabel("预测概率", fontsize=12)
ax.set_title("8件未知玻璃文物分类预测概率分布", fontsize=14, fontweight='bold')
ax.set_ylim(0, 1.1)
ax.legend(fontsize=11)
ax.grid(axis='y', alpha=0.3)
ax.axhline(y=0.5, color='red', linestyle='--', alpha=0.5, label='决策阈值(0.5)')

for i, row in results.iterrows():
    pred_type = row['预测类型']
    color = '#638bd6' if pred_type == '高钾' else '#e67e22'
    ax.text(i, 0.05, pred_type, ha='center', va='bottom', fontsize=10, 
            color='white', fontweight='bold', bbox=dict(boxstyle='round,pad=0.3', facecolor=color, alpha=0.8))

plt.tight_layout()
plt.savefig('图5-4_未知样本预测概率图.png', dpi=300, bbox_inches='tight')
print("已保存：图5-4_未知样本预测概率图.png")

# 8.2 阈值敏感性变化折线图
fig, ax = plt.subplots(figsize=(10, 6))
for idx, row in results.iterrows():
    ax.plot(thresholds, [row['铅钡概率'] for _ in thresholds], 
            'o-', label=row['文物编号'], linewidth=2, markersize=8)

ax.axhline(y=0.5, color='red', linestyle='--', alpha=0.5, label='决策阈值')
ax.set_xlabel('分类阈值', fontsize=12)
ax.set_ylabel('铅钡概率', fontsize=12)
ax.set_title('不同阈值下各未知样本的铅钡概率变化', fontsize=14, fontweight='bold')
ax.set_xticks(thresholds)
ax.legend(loc='best', fontsize=9)
ax.grid(axis='y', alpha=0.3)
plt.tight_layout()
plt.savefig('图5-5_阈值敏感性变化图.png', dpi=300, bbox_inches='tight')
print("已保存：图5-5_阈值敏感性变化图.png")

plt.show()

# ====================== 9. 结论汇总 ======================
print("\\n" + "=" * 70)
print("问题3 结论汇总")
print("=" * 70)

print("\\n【未知样本类型鉴别结果】")
type_counts = results['预测类型'].value_counts()
print(f"  高钾玻璃：{type_counts.get('高钾', 0)} 件")
print(f"  铅钡玻璃：{type_counts.get('铅钡', 0)} 件")
print(f"  总样本数：{len(results)} 件")

print("\\n【各样本详细结果】")
for _, row in results.iterrows():
    print(f"  {row['文物编号']}: {row['预测类型']} (高钾{row['高钾概率']:.2%}, 铅钡{row['铅钡概率']:.2%})")

print("\\n【敏感性分析结论】")
print("  1. 概率阈值敏感性：在0.3~0.7范围内，所有样本分类结果稳定")
if unstable_id:
    print(f"  2. 特征扰动敏感性：{unstable_id}在PbO扰动后需关注")
else:
    print("  2. 特征扰动敏感性：所有样本在PbO±10%扰动下分类结果稳定")

print("\\n" + "=" * 70)
print("===== 重要预测局限性提示 =====")
print("1. 本模型仅使用无风化样本训练，未知样本存在表面风化，PbO等成分可能因淋溶流失，预测存在潜在偏差；")
print("2. 若风化样本预测为高钾，但原始PbO接近0，可信度更高；若风化样本预测为铅钡但PbO极低，需人工复核；")
print("3. 风化严重样本建议结合考古背景综合判定，不可仅依靠模型输出。")
print("=" * 70)
print("分析完成！")
print("=" * 70)