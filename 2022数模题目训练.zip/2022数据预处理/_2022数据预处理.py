﻿"""
古代玻璃制品成分分析与鉴别 - 数据预处理完整修复版 v2
修复：正则转义、续行符、换行打印、风化配对、新增化学异常标记
适配2022国赛C题完整4个问题
"""
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import warnings
import json
import os
warnings.filterwarnings('ignore')

# ==================== 1. 数据加载 ====================
print("\n" + "="*60)
print("1. 加载数据")
print("="*60)
file_path = '附件_20260731211954.xlsx'
form1 = pd.read_excel(file_path, sheet_name='表单1')
form2 = pd.read_excel(file_path, sheet_name='表单2')
form3 = pd.read_excel(file_path, sheet_name='表单3')

print(f"表单1: {form1.shape} 条记录")
print(f"表单2: {form2.shape} 条记录")
print(f"表单3: {form3.shape} 条记录")

# ==================== 2. 多表融合 ====================
print("\n" + "="*60)
print("2. 多表融合")
print("="*60)
# 表单2提取数字文物编号（修复正则 \d）
form2['文物编号'] = form2['文物采样点'].str.extract(r'(\d+)')
form2['文物编号'] = form2['文物编号'].fillna(0).astype(int)
# 表单3无需提取数字，删除多余文物编号_str代码
df = pd.merge(form2, form1, on='文物编号', how='left')
print(f"合并后训练数据: {df.shape[0]} 条采样记录")

# ==================== 3. 定义成分列 ====================
component_cols = ['二氧化硅(SiO2)', '氧化钠(Na2O)', '氧化钾(K2O)', '氧化钙(CaO)',
                  '氧化镁(MgO)', '氧化铝(Al2O3)', '氧化铁(Fe2O3)', '氧化铜(CuO)',
                  '氧化铅(PbO)', '氧化钡(BaO)', '五氧化二磷(P2O5)', '氧化锶(SrO)',
                  '氧化锡(SnO2)', '二氧化硫(SO2)']

# ==================== 4. 有效样本筛选 ====================
print("\n" + "="*60)
print("3. 数据有效性筛选")
print("="*60)
def filter_valid_data(data, component_cols):
    data = data.copy()
    data[component_cols] = data[component_cols].fillna(0)
    sum_vals = data[component_cols].sum(axis=1)
    valid_mask = (sum_vals >= 85) & (sum_vals <= 105)
    invalid_indices = data.index[~valid_mask].tolist()
    valid_data = data[valid_mask].copy()
    return valid_data, invalid_indices, sum_vals[valid_mask]

df_valid, invalid_train, sum_train = filter_valid_data(df, component_cols)
form3_valid, invalid_test, sum_test = filter_valid_data(form3, component_cols)
print(f"训练集: 原始 {len(df)} 条, 有效 {len(df_valid)} 条")
print(f"测试集: 原始 {len(form3)} 条, 有效 {len(form3_valid)} 条")

# ==================== 5. 定和归一 + CLR变换 ====================
print("\n" + "="*60)
print("4. 成分归一化 + CLR对数比变换")
print("="*60)
def normalize_components(data, comp_cols):
    data = data.copy()
    row_sums = data[comp_cols].sum(axis=1)
    row_sums = row_sums.replace(0, 1e-8)
    data[comp_cols] = data[comp_cols].div(row_sums, axis=0) * 100
    return data

def clr_transform(data, comp_cols, eps=1e-6):
    data = data.copy()
    mat = data[comp_cols].values + eps
    log_mat = np.log(mat)
    geo_log_mean = np.mean(log_mat, axis=1, keepdims=True)
    clr_mat = log_mat - geo_log_mean
    clr_names = [f"clr_{c}" for c in comp_cols]
    for i, name in enumerate(clr_names):
        data[name] = clr_mat[:, i]
    return data, clr_names

df_valid = normalize_components(df_valid, component_cols)
df_valid, clr_cols = clr_transform(df_valid, component_cols)
form3_valid = normalize_components(form3_valid, component_cols)
form3_valid, _ = clr_transform(form3_valid, component_cols)
print(f"完成CLR变换，新增{len(clr_cols)}个CLR特征")

# ==================== 6. 特征工程 ====================
print("\n" + "="*60)
print("5. 特征工程")
print("="*60)
def create_features(data, is_train=True, train_dummy_cols=None):
    data = data.copy()
    # 风化编码
    if '表面风化' in data.columns:
        data['风化_编码'] = data['表面风化'].map({'无风化': 0, '风化': 1})
        def wind_level(row):
            samp = str(row.get('文物采样点', ''))
            base = row.get('表面风化', '')
            if base == "无风化":
                return 0
            if "未风化点" in samp:
                return 1
            elif "严重风化点" in samp:
                return 3
            else:
                return 2
        data['风化等级'] = data.apply(wind_level, axis=1)
    # 类型编码 + 化学异常标记（新增）
    dummy_cols = []
    if '类型' in data.columns:
        data['类型_编码'] = data['类型'].map({'高钾': 0, '铅钡': 1})
        def chem_abnormal(row):
            t = row['类型_编码']
            pb, ba, k = row['氧化铅(PbO)'], row['氧化钡(BaO)'], row['氧化钾(K2O)']
            if t == 0 and (pb > 5 or ba > 5):
                return 1
            if t == 1 and k > 10:
                return 1
            return 0
        data['化学异常'] = data.apply(chem_abnormal, axis=1)
    # 纹饰独热
    if '纹饰' in data.columns and is_train:
        orn_dum = pd.get_dummies(data['纹饰'], prefix='纹饰', dtype=int)
        data = pd.concat([data, orn_dum], axis=1)
        dummy_cols += list(orn_dum.columns)
        data['颜色'] = data['颜色'].fillna('未知')
        col_dum = pd.get_dummies(data['颜色'], prefix='颜色', dtype=int)
        data = pd.concat([data, col_dum], axis=1)
        dummy_cols += list(col_dum.columns)
    elif not is_train:
        for col in train_dummy_cols:
            data[col] = 0
    return data, dummy_cols

# 训练集生成独热列
df_valid, dummy_cols = create_features(df_valid, is_train=True)
# 测试集补齐独热列
form3_valid, _ = create_features(form3_valid, is_train=False, train_dummy_cols=dummy_cols)

# 比值特征（修复续行符）
eps = 1e-6
df_valid['PbO_BaO_ratio'] = df_valid['氧化铅(PbO)'] / (df_valid['氧化钡(BaO)'] + eps)
df_valid['PbO_BaO_ratio'] = df_valid['PbO_BaO_ratio'].clip(upper=1000)
df_valid['K2O_SiO2_ratio'] = df_valid['氧化钾(K2O)'] / (df_valid['二氧化硅(SiO2)'] + eps)
df_valid['flux_network_ratio'] = (df_valid['氧化铅(PbO)'] + df_valid['氧化钡(BaO)']) / (
    df_valid['二氧化硅(SiO2)'] + df_valid['氧化铝(Al2O3)'] + eps
)

form3_valid['PbO_BaO_ratio'] = form3_valid['氧化铅(PbO)'] / (form3_valid['氧化钡(BaO)'] + eps)
form3_valid['PbO_BaO_ratio'] = form3_valid['PbO_BaO_ratio'].clip(upper=1000)
form3_valid['K2O_SiO2_ratio'] = form3_valid['氧化钾(K2O)'] / (form3_valid['二氧化硅(SiO2)'] + eps)
form3_valid['flux_network_ratio'] = (form3_valid['氧化铅(PbO)'] + form3_valid['氧化钡(BaO)']) / (
    form3_valid['二氧化硅(SiO2)'] + form3_valid['氧化铝(Al2O3)'] + eps
)
extra_feats = ['PbO_BaO_ratio', 'K2O_SiO2_ratio', 'flux_network_ratio']
print(f"新增特征：风化等级、化学异常、{len(dummy_cols)}个独热特征、3组比值特征")

# ==================== 7. 任务子集划分 ====================
print("\n" + "="*60)
print("6. 多任务数据集拆分")
print("="*60)
# 分类集：仅无风化/局部未风化（等级0、1），剔除严重风化3
classification_mask = df_valid['风化等级'].isin([0, 1])
df_class = df_valid[classification_mask].copy()
# 风化建模集：普通/严重风化（等级2、3）
df_weather = df_valid[df_valid['风化等级'] >= 2].copy()
# 全量统计集
df_all = df_valid.copy()
print(f"分类建模集(问题2/3): {len(df_class)} 条")
print(f"风化回归集(问题1): {len(df_weather)} 条")
print(f"全量统计集(问题1/4): {len(df_all)} 条")

# ==================== 8. 特征集构建与标准化 ====================
print("\n" + "="*60)
print("7. 训练集拆分与标准化")
print("="*60)
feature_cols = component_cols + clr_cols + extra_feats + dummy_cols
feature_cols = [c for c in feature_cols if c in df_all.columns]
X_all = df_all[feature_cols].copy()
y_all = df_all['类型_编码']
X_class = df_class[feature_cols].copy()
y_class = df_class['类型_编码']

# 校验文物编号是否存在
print("=====校验df_class字段=====")
print("df_class列名：", df_class.columns.tolist())
print("是否包含文物编号：", "文物编号" in df_class.columns)
print("df_class行数：", len(df_class))
# 按文物分层拆分训练/验证集
print("df_class所有列：", df_class.columns.tolist())
if "文物编号" in df_class.columns and df_class["文物编号"].nunique() >= 5:
    unique_ids = df_class['文物编号'].unique()
    train_ids, val_ids = train_test_split(unique_ids, test_size=0.2, random_state=42)
    train_mask = df_class['文物编号'].isin(train_ids)
    val_mask = df_class['文物编号'].isin(val_ids)
    X_train = X_class[train_mask].copy()
    X_val = X_class[val_mask].copy()
    y_train = y_class[train_mask].copy()
    y_val = y_class[val_mask].copy()
    print(f"文物分层划分：训练文物{len(train_ids)}个，验证文物{len(val_ids)}个")
else:
    # 无文物编号/文物数量不足，改用标签分层随机划分
    print("未找到文物编号或文物样本过少，切换分层随机划分")
    X_train, X_val, y_train, y_val = train_test_split(
        X_class, y_class, test_size=0.2, random_state=42, stratify=y_class
    )

# 标准化（仅训练集拟合）
scaler = StandardScaler()
X_train_sc = pd.DataFrame(scaler.fit_transform(X_train), columns=feature_cols, index=X_train.index)
X_val_sc = pd.DataFrame(scaler.transform(X_val), columns=feature_cols, index=X_val.index)
X_all_sc = pd.DataFrame(scaler.transform(X_all), columns=feature_cols, index=X_all.index)
X_test_raw = form3_valid[feature_cols].copy()
X_test_sc = pd.DataFrame(scaler.transform(X_test_raw), columns=feature_cols, index=X_test_raw.index)
print(f"训练集{len(X_train)}条，验证集{len(X_val)}，标准化完成")

# ==================== 9. 风化配对（修复：包含局部未风化点） ====================
print("\n" + "="*60)
print("8. 风化-原始成分配对样本")
print("="*60)
pairs = []
for wid in df_all['文物编号'].unique():
    sub = df_all[df_all['文物编号'] == wid]
    # 原始样本：整体无风化0 / 风化文物局部未风化1
    origin = sub[sub['风化等级'].isin([0, 1])]
    # 风化样本：普通/严重风化
    wea = sub[sub['风化等级'] >= 2]
    if len(origin) > 0 and len(wea) > 0:
        for _, orig in origin.iterrows():
            for _, w in wea.iterrows():
                pairs.append({
                    '文物编号': wid,
                    '风化等级': w['风化等级'],
                    '风化成分': w[component_cols].tolist(),
                    '原始未风化成分': orig[component_cols].tolist()
                })
df_pairs = pd.DataFrame(pairs) if pairs else pd.DataFrame()
print(f"风化配对样本共{len(df_pairs)}组")

# ==================== 10. 数据导出与日志 ====================
print("\n" + "="*60)
print("9. 导出预处理文件")
print("="*60)
out_dir = './preprocessed_data/'
os.makedirs(out_dir, exist_ok=True)
# 分类建模
X_train_sc.to_csv(f"{out_dir}X_train.csv", index=False)
X_val_sc.to_csv(f"{out_dir}X_val.csv", index=False)
y_train.to_csv(f"{out_dir}y_train.csv", index=False)
y_val.to_csv(f"{out_dir}y_val.csv", index=False)
# 全量数据
X_all_sc.to_csv(f"{out_dir}X_all_scaled.csv", index=False)
df_all.to_csv(f"{out_dir}df_all_preprocessed.csv", index=False)
# 风化数据
df_weather.to_csv(f"{out_dir}df_weather_samples.csv", index=False)
if len(df_pairs):
    df_pairs.to_csv(f"{out_dir}weather_pairs.csv", index=False)
# 未知文物
X_test_sc.to_csv(f"{out_dir}X_test_unknown.csv", index=False)
form3_valid.to_csv(f"{out_dir}form3_unknown_preprocessed.csv", index=False)

# 清洗日志
log = {
    '原始训练样本': len(df),
    '有效训练样本': len(df_valid),
    '剔除训练样本': len(invalid_train),
    '分类任务样本': len(df_class),
    '风化回归样本': len(df_weather),
    '风化配对组数': len(df_pairs),
    '未知文物': len(form3_valid),
    '总特征数': len(feature_cols),
    'CLR特征数': len(clr_cols)
}
with open(f"{out_dir}清洗日志.json", "w", encoding="utf-8") as f:
    json.dump(log, f, ensure_ascii=False, indent=2)

print(f"全部文件输出至 {out_dir}")
print("\n" + "="*60)
print("数据预处理全部完成！")
print("="*60)