﻿"""
问题4：两类玻璃化学成分关联差异分析（完整优化版）
- 排除风化干扰（仅用无风化样本）
- 常量列NaN处理（高钾PbO、BaO自动标记）
- 样本量说明（高钾n=12，铅钡n=23）
- 相关系数矩阵 + 差异矩阵
- 显著性检验（p值）
- 核心成分均值对比
- 三张热力图 + 条形图
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import pearsonr
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

# ====================== 1. 加载数据 ======================
print("=" * 70)
print("问题4：两类玻璃化学成分关联差异分析")
print("=" * 70)

df_all = pd.read_csv('df_all_preprocessed.csv')

# ===== 只使用无风化样本，排除风化干扰 =====
df_unweathered = df_all[df_all['风化等级'].isin([0, 1])].copy()
print(f"\\n【数据说明】采用无风化样本（风化等级0和1），排除风化对成分关联的干扰")
print(f"  总无风化样本数：{len(df_unweathered)} 条")
print(f"  高钾玻璃：{len(df_unweathered[df_unweathered['类型']=='高钾'])} 条 ⚠️ 样本量偏少，相关系数稳定性较低")
print(f"  铅钡玻璃：{len(df_unweathered[df_unweathered['类型']=='铅钡'])} 条")

# 成分列
component_cols = ['二氧化硅(SiO2)', '氧化钠(Na2O)', '氧化钾(K2O)', '氧化钙(CaO)',
                  '氧化镁(MgO)', '氧化铝(Al2O3)', '氧化铁(Fe2O3)', '氧化铜(CuO)',
                  '氧化铅(PbO)', '氧化钡(BaO)', '五氧化二磷(P2O5)', '氧化锶(SrO)',
                  '氧化锡(SnO2)', '二氧化硫(SO2)']

short_names = ['SiO₂', 'Na₂O', 'K₂O', 'CaO', 'MgO', 'Al₂O₃', 'Fe₂O₃', 
               'CuO', 'PbO', 'BaO', 'P₂O₅', 'SrO', 'SnO₂', 'SO₂']

# ====================== 2. 按类型分组 ======================
df_highK = df_unweathered[df_unweathered['类型'] == '高钾'][component_cols].copy()
df_leadBa = df_unweathered[df_unweathered['类型'] == '铅钡'][component_cols].copy()

# ===== 识别高钾玻璃中的常量列（PbO、BaO全部为0）=====
const_cols = []
for col in df_highK.columns:
    if df_highK[col].std() == 0:
        const_cols.append(col)

print(f"\\n【高钾玻璃常量成分】{const_cols}（含量恒为0，无相关性）")
print(f"  这些成分不参与相关系数差异筛选（相关系数无意义，标记为'-'）")

# 高钾玻璃中非常量列
highK_cols_with_var = [col for col in df_highK.columns if col not in const_cols]
corr_highK = df_highK[highK_cols_with_var].corr(method='pearson')
corr_leadBa = df_leadBa.corr(method='pearson')

print("\\n高钾玻璃相关系数矩阵（前5行）：")
print(corr_highK.iloc[:5, :5].round(3))

print("\\n铅钡玻璃相关系数矩阵（前5行）：")
print(corr_leadBa.iloc[:5, :5].round(3))

# ====================== 3. 计算差异矩阵 ======================
common_cols = list(set(highK_cols_with_var) & set(corr_leadBa.columns))
common_cols = sorted(common_cols)

corr_highK_aligned = corr_highK.loc[common_cols, common_cols]
corr_leadBa_aligned = corr_leadBa.loc[common_cols, common_cols]
diff_corr = corr_highK_aligned - corr_leadBa_aligned

print("\\n相关系数差异矩阵（高钾 - 铅钡）：")
print(diff_corr.iloc[:5, :5].round(3))

# ====================== 4. 提取显著差异的相关系数对 ======================
print("\\n" + "=" * 70)
print("显著差异的相关系数对（|差异| > 0.3）")
print("=" * 70)

common_short = [short_names[component_cols.index(c)] for c in common_cols]

diff_pairs = []
for i in range(len(common_cols)):
    for j in range(i + 1, len(common_cols)):
        diff_val = diff_corr.iloc[i, j]
        if abs(diff_val) > 0.3:
            highK_corr = corr_highK_aligned.iloc[i, j]
            leadBa_corr = corr_leadBa_aligned.iloc[i, j]
            diff_pairs.append({
                '成分1': common_short[i],
                '成分2': common_short[j],
                '高钾相关系数': highK_corr,
                '铅钡相关系数': leadBa_corr,
                '差异': diff_val,
                '差异方向': '高钾更强' if diff_val > 0 else '铅钡更强'
            })

diff_pairs_sorted = sorted(diff_pairs, key=lambda x: abs(x['差异']), reverse=True)

print(f"\\n【共发现 {len(diff_pairs_sorted)} 对差异显著的成分】")
print("-" * 80)
print(f"{'成分1':<10} {'成分2':<10} {'高钾r':>10} {'铅钡r':>10} {'差异':>10} {'方向':<12}")
print("-" * 80)
for p in diff_pairs_sorted[:10]:
    print(f"{p['成分1']:<10} {p['成分2']:<10} {p['高钾相关系数']:>10.3f} {p['铅钡相关系数']:>10.3f} {p['差异']:>10.3f} {p['差异方向']:<12}")
print("-" * 80)

# ====================== 4.5 相关系数显著性检验 ======================
print("\\n" + "=" * 70)
print("相关系数显著性检验（p值）")
print("=" * 70)

def corr_with_pvalue(data, col1, col2):
    """计算相关系数和p值"""
    x = data[col1].dropna().values
    y = data[col2].dropna().values
    if len(x) < 3 or len(y) < 3:
        return np.nan, np.nan
    r, p = pearsonr(x, y)
    return r, p

print("\\n【差异最大5对成分的显著性检验】")
print("-" * 80)
print(f"{'成分对':<20} {'高钾p值':>12} {'铅钡p值':>12} {'高钾显著?':>12} {'铅钡显著?':>12}")
print("-" * 80)
for p in diff_pairs_sorted[:5]:
    col1 = component_cols[short_names.index(p['成分1'])]
    col2 = component_cols[short_names.index(p['成分2'])]
    _, p_hk = corr_with_pvalue(df_highK, col1, col2)
    _, p_pb = corr_with_pvalue(df_leadBa, col1, col2)
    sig_hk = '是' if p_hk < 0.05 else ('否' if not np.isnan(p_hk) else '-')
    sig_pb = '是' if p_pb < 0.05 else ('否' if not np.isnan(p_pb) else '-')
    print(f"{p['成分1']}-{p['成分2']:<14} {p_hk:>12.4f} {p_pb:>12.4f} {sig_hk:>12} {sig_pb:>12}")
print("-" * 80)

# ====================== 4.6 核心判别成分均值对比 ======================
print("\\n" + "=" * 70)
print("高钾与铅钡玻璃核心判别成分对比")
print("=" * 70)

core_cols = ['氧化铅(PbO)', '氧化钡(BaO)', '氧化钾(K2O)', '氧化钠(Na2O)']
print("\\n【核心判别成分均值对比】")
print("-" * 70)
print(f"{'成分':<15} {'高钾玻璃均值(%)':>18} {'铅钡玻璃均值(%)':>18} {'差值(铅钡-高钾)':>18}")
print("-" * 70)
for col in core_cols:
    hk_mean = df_highK[col].mean()
    pb_mean = df_leadBa[col].mean()
    diff_mean = pb_mean - hk_mean
    print(f"{col:<15} {hk_mean:>18.2f} {pb_mean:>18.2f} {diff_mean:>18.2f}")
print("-" * 70)

# ====================== 5. 可视化 ======================
print("\\n" + "=" * 70)
print("生成可视化图表")
print("=" * 70)

# 5.1 高钾玻璃相关热力图
fig, ax = plt.subplots(figsize=(12, 10))
full_corr_highK = pd.DataFrame(np.nan, index=short_names, columns=short_names)
for i, c1 in enumerate(common_cols):
    for j, c2 in enumerate(common_cols):
        full_corr_highK.loc[short_names[component_cols.index(c1)], 
                            short_names[component_cols.index(c2)]] = corr_highK_aligned.iloc[i, j]
mask = np.triu(np.ones_like(full_corr_highK, dtype=bool))
sns.heatmap(full_corr_highK, mask=mask, annot=True, fmt='.2f', cmap='RdBu_r',
            center=0, vmin=-1, vmax=1, square=True,
            xticklabels=True, yticklabels=True,
            ax=ax, cbar_kws={'label': '相关系数'})
ax.set_title(f'高钾玻璃化学成分相关系数矩阵（n={len(df_highK)}）', fontsize=14, fontweight='bold')
if const_cols:
    const_names = [short_names[component_cols.index(c)] for c in const_cols if c in component_cols]
    ax.text(0.5, -0.08, f'注：{", ".join(const_names)} 含量恒为0，无相关性', 
            transform=ax.transAxes, ha='center', fontsize=10, color='gray')
plt.tight_layout()
plt.savefig('图5-6_高钾玻璃相关性热力图.png', dpi=300, bbox_inches='tight')
print("已保存：图5-6_高钾玻璃相关性热力图.png")

# 5.2 铅钡玻璃相关热力图
fig, ax = plt.subplots(figsize=(12, 10))
mask = np.triu(np.ones_like(corr_leadBa, dtype=bool))
sns.heatmap(corr_leadBa, mask=mask, annot=True, fmt='.2f', cmap='RdBu_r',
            center=0, vmin=-1, vmax=1, square=True,
            xticklabels=short_names, yticklabels=short_names,
            ax=ax, cbar_kws={'label': '相关系数'})
ax.set_title(f'铅钡玻璃化学成分相关系数矩阵（n={len(df_leadBa)}）', fontsize=14, fontweight='bold')
plt.tight_layout()
plt.savefig('图5-7_铅钡玻璃相关性热力图.png', dpi=300, bbox_inches='tight')
print("已保存：图5-7_铅钡玻璃相关性热力图.png")

# 5.3 差异热力图
fig, ax = plt.subplots(figsize=(10, 8))
sns.heatmap(diff_corr, annot=True, fmt='.2f', cmap='coolwarm',
            center=0, vmin=-0.8, vmax=0.8, square=True,
            xticklabels=common_short, yticklabels=common_short,
            ax=ax, cbar_kws={'label': '相关系数差异（高钾-铅钡）'})
ax.set_title('两类玻璃相关系数差异矩阵（高钾 - 铅钡）', fontsize=14, fontweight='bold')
ax.text(0.5, -0.06, f'注：高钾n={len(df_highK)}，铅钡n={len(df_leadBa)}，高钾样本偏少，结果仅供参考',
        transform=ax.transAxes, ha='center', fontsize=10, color='gray')
plt.tight_layout()
plt.savefig('图5-8_两类玻璃相关性差异热力图.png', dpi=300, bbox_inches='tight')
print("已保存：图5-8_两类玻璃相关性差异热力图.png")

# 5.4 差异最大的5对成分的相关系数对比条形图
fig, ax = plt.subplots(figsize=(10, 6))
if len(diff_pairs_sorted) > 0:
    top_n = min(5, len(diff_pairs_sorted))
    x = np.arange(top_n)
    width = 0.35
    
    highK_vals = [p['高钾相关系数'] for p in diff_pairs_sorted[:top_n]]
    leadBa_vals = [p['铅钡相关系数'] for p in diff_pairs_sorted[:top_n]]
    labels = [f"{p['成分1']}-{p['成分2']}" for p in diff_pairs_sorted[:top_n]]
    
    ax.bar(x - width/2, highK_vals, width, label='高钾玻璃', color='#638bd6')
    ax.bar(x + width/2, leadBa_vals, width, label='铅钡玻璃', color='#e67e22')
    ax.axhline(y=0, color='black', linestyle='-', linewidth=0.5)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=15, ha='right')
    ax.set_ylabel('相关系数')
    ax.set_title(f'差异最大的{top_n}对化学成分相关系数对比', fontsize=14, fontweight='bold')
    ax.legend()
    plt.tight_layout()
    plt.savefig('图5-9_关键成分相关系数对比图.png', dpi=300, bbox_inches='tight')
    print("已保存：图5-9_关键成分相关系数对比图.png")

plt.show()

# ====================== 6. 结论汇总 ======================
print("\\n" + "=" * 70)
print("问题4 结论汇总（论文可直接使用）")
print("=" * 70)

print("\\n【数据说明】")
print(f"  高钾玻璃：{len(df_highK)} 条（样本偏少，相关系数稳定性较低）")
print(f"  铅钡玻璃：{len(df_leadBa)} 条")
if const_cols:
    const_names = [short_names[component_cols.index(c)] for c in const_cols if c in component_cols]
    print(f"  高钾玻璃常量成分：{', '.join(const_names)}（含量恒为0，不参与相关性分析）")

print("\\n【两类玻璃成分关联结构的核心差异】")
if len(diff_pairs_sorted) > 0:
    print(f"  共发现 {len(diff_pairs_sorted)} 对成分的相关系数差异大于0.3")
    print(f"  差异最大的前5对：")
    for i, p in enumerate(diff_pairs_sorted[:5]):
        print(f"    {i+1}. {p['成分1']}-{p['成分2']}: 高钾{p['高钾相关系数']:.3f} vs 铅钡{p['铅钡相关系数']:.3f} (差异{abs(p['差异']):.3f})")

print("\\n【核心判别成分均值对比】")
print("-" * 55)
print(f"{'成分':<12} {'高钾均值':>12} {'铅钡均值':>12} {'差值':>12}")
print("-" * 55)
for col in core_cols:
    hk_mean = df_highK[col].mean()
    pb_mean = df_leadBa[col].mean()
    print(f"{col:<12} {hk_mean:>12.2f} {pb_mean:>12.2f} {pb_mean-hk_mean:>12.2f}")
print("-" * 55)

print("\\n【化学机理解释】")
print("-" * 70)
print("1. 铅钡玻璃中PbO与BaO强正相关（均来自铅矿石助熔剂），高钾玻璃两者恒为0")
print("2. 高钾玻璃中K₂O与SiO₂负相关更明显（K⁺为网络外离子）")
print("3. 两类玻璃中Al₂O₃与SiO₂均保持正相关（铝硅酸盐骨架的共性）")

print("\\n【局限性说明】")
print("-" * 70)
print("1. 高钾玻璃无风化样本仅12条，相关系数置信区间较宽，结论需谨慎解读")
print("2. 部分成分（PbO、BaO）在高钾玻璃中含量恒为0，相关系数无意义，已排除")
print("3. 本研究仅采用无风化样本，结果反映了原始烧制配方的内在关联")

print("\\n" + "=" * 70)
print("分析完成！")
print("=" * 70)