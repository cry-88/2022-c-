﻿"""
C题 问题1 完整分析：风化成分统计规律 + 风化前成分预测
对应论文 5.2 节
修复：遍历合并表天然对齐，彻底解决长度不匹配问题
"""

import pandas as pd
import numpy as np
from scipy import stats
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

# ====================== 1. 加载数据 ======================
df_all = pd.read_csv('df_all_preprocessed.csv')
df_pairs = pd.read_csv('weather_pairs.csv')

component_cols = ['二氧化硅(SiO2)', '氧化钠(Na2O)', '氧化钾(K2O)', '氧化钙(CaO)',
                  '氧化镁(MgO)', '氧化铝(Al2O3)', '氧化铁(Fe2O3)', '氧化铜(CuO)',
                  '氧化铅(PbO)', '氧化钡(BaO)', '五氧化二磷(P2O5)', '氧化锶(SrO)',
                  '氧化锡(SnO2)', '二氧化硫(SO2)']

# 简短列名用于显示
short_names = ['SiO₂', 'Na₂O', 'K₂O', 'CaO', 'MgO', 'Al₂O₃', 'Fe₂O₃', 
               'CuO', 'PbO', 'BaO', 'P₂O₅', 'SrO', 'SnO₂', 'SO₂']

print("="*70)
print("问题1：风化成分统计规律 + 风化前成分预测")
print("="*70)

# ====================== 2. 数据分组 ======================
# 无风化组：风化等级0（无风化文物）+ 风化等级1（未风化点）
df_no_weather = df_all[df_all['风化等级'].isin([0, 1])].copy()
# 风化组：风化等级>=2
df_weathered = df_all[df_all['风化等级'] >= 2].copy()

print(f"\\n样本分布（按采样点统计）：")
print(f"  无风化组（等级0+1）：{len(df_no_weather)} 条")
print(f"  风化组（等级>=2）：{len(df_weathered)} 条")
print(f"  总计：{len(df_no_weather) + len(df_weathered)} 条")

for glass_type in df_all['类型'].unique():
    n_no = len(df_no_weather[df_no_weather['类型'] == glass_type])
    n_w = len(df_weathered[df_weathered['类型'] == glass_type])
    print(f"  {glass_type}玻璃：无风化{n_no}条，风化{n_w}条")

# ====================== 3. 统计对比函数 ======================
def calc_stats(data, label):
    """计算14种氧化物的均值±标准差"""
    stats_df = pd.DataFrame({
        '氧化物': component_cols,
        '简称': short_names,
        f'{label}_均值': data[component_cols].mean(),
        f'{label}_标准差': data[component_cols].std(),
        f'{label}_样本数': len(data)
    })
    return stats_df

def run_ttest(group1, group2, col):
    """执行独立样本t检验"""
    vals1 = group1[col].dropna().values
    vals2 = group2[col].dropna().values
    if len(vals1) < 2 or len(vals2) < 2:
        return np.nan, np.nan
    t_stat, p_val = stats.ttest_ind(vals1, vals2)
    return t_stat, p_val

def cohens_d(group1, group2, col):
    """计算Cohen's d效应量"""
    vals1 = group1[col].dropna().values
    vals2 = group2[col].dropna().values
    if len(vals1) < 2 or len(vals2) < 2:
        return np.nan
    n1, n2 = len(vals1), len(vals2)
    var1, var2 = np.var(vals1, ddof=1), np.var(vals2, ddof=1)
    pooled_var = ((n1 - 1) * var1 + (n2 - 1) * var2) / (n1 + n2 - 2)
    d = (np.mean(vals1) - np.mean(vals2)) / np.sqrt(pooled_var)
    return d

def effect_size_label(d):
    """效应量分级标签"""
    if np.isnan(d):
        return '-'
    if abs(d) < 0.2:
        return '微小'
    elif abs(d) < 0.5:
        return '小'
    elif abs(d) < 0.8:
        return '中'
    else:
        return '大'

# ====================== 4. 按类型分别统计 ======================
print("\\n" + "="*70)
print("5.2.2 不同类型玻璃的风化成分统计规律")
print("="*70)

results = {}

for glass_type in df_all['类型'].unique():
    print(f"\\n{'='*50}")
    print(f"【{glass_type}玻璃】")
    
    no_w = df_no_weather[df_no_weather['类型'] == glass_type]
    w = df_weathered[df_weathered['类型'] == glass_type]
    
    if len(no_w) == 0 or len(w) == 0:
        print(f"  样本不足，跳过")
        continue
    
    # 计算统计量
    stats_no = calc_stats(no_w, '无风化')
    stats_w = calc_stats(w, '风化')
    stats_compare = pd.merge(stats_no, stats_w, on=['氧化物', '简称'])
    
    # ====== 【修复核心】直接遍历合并统计表，天然14行对齐 ======
    diff_list, p_list, d_list, sig_list = [], [], [], []
    
    for _, row_cmp in stats_compare.iterrows():
        ox_name = row_cmp['氧化物']
        # 直接从当前行取均值，无需重复查表
        diff = row_cmp['风化_均值'] - row_cmp['无风化_均值']
        t_stat, p = run_ttest(no_w, w, ox_name)
        d = cohens_d(no_w, w, ox_name)

        diff_list.append(diff)
        p_list.append(p)
        d_list.append(d)

        # 规范显著性标记逻辑
        if np.isnan(p):
            sig_list.append('-')
        elif p < 0.01:
            sig_list.append('**')
        elif p < 0.05:
            sig_list.append('*')
        else:
            sig_list.append('ns')
    
    # 列表长度和stats_compare行数完全一致
    stats_compare['差值(风化-无风化)'] = diff_list
    stats_compare['p值'] = p_list
    stats_compare['显著性'] = sig_list
    stats_compare['Cohen_d'] = d_list          # 【改】使用 Cohen_d 代替 Cohen's d
    stats_compare['效应量'] = [effect_size_label(d) for d in d_list]
    
    # 变化机理
    mechanism = []
    for _, row in stats_compare.iterrows():
        diff = row['差值(风化-无风化)']
        if diff > 0.5:
            mechanism.append('被动富集' if row['氧化物'] == '二氧化硅(SiO2)' else '富集')
        elif diff < -0.5:
            if row['氧化物'] == '氧化铅(PbO)':
                mechanism.append('Pb²⁺离子溶出')
            elif row['氧化物'] == '氧化钡(BaO)':
                mechanism.append('Ba²⁺离子迁移')
            elif row['氧化物'] == '氧化钾(K2O)':
                mechanism.append('K⁺离子交换溶出')
            else:
                mechanism.append('流失')
        else:
            mechanism.append('相对稳定')
    stats_compare['变化机理'] = mechanism
    
    results[glass_type] = stats_compare
    
    # 输出表格（论文表5-1/5-2格式）
    print(f"\\n  无风化样本量: {len(no_w)}，风化样本量: {len(w)}")
    print("\\n  " + "-" * 120)
    # 【改】表头用 Cohen_d
    print(f"  {'氧化物':<12} {'无风化均值(%)':>12} {'风化均值(%)':>12} {'差值(百分点)':>12} {'p值':>10} {'显著性':>6} {'Cohen_d':>10} {'效应量':>6} {'变化机理':<15}")
    print("  " + "-" * 120)
    for _, row in stats_compare.iterrows():
        # 【改】数据行用 row['Cohen_d']
        print(f"  {row['简称']:<12} {row['无风化_均值']:>12.2f} {row['风化_均值']:>12.2f} {row['差值(风化-无风化)']:>12.2f} {row['p值']:>10.4f} {row['显著性']:>6} {row['Cohen_d']:>10.2f} {row['效应量']:>6} {row['变化机理']:<15}")
    print("  " + "-" * 120)

# ====================== 5. 两类玻璃风化规律的核心差异 ======================
print("\\n" + "="*70)
print("5.2.3 两类玻璃风化规律的核心差异")
print("="*70)

if '铅钡' in results and '高钾' in results:
    pb_diff = results['铅钡'][results['铅钡']['氧化物'] == '氧化铅(PbO)']['差值(风化-无风化)'].values[0]
    ba_diff = results['铅钡'][results['铅钡']['氧化物'] == '氧化钡(BaO)']['差值(风化-无风化)'].values[0]
    k_diff = results['高钾'][results['高钾']['氧化物'] == '氧化钾(K2O)']['差值(风化-无风化)'].values[0]
    
    print("\\n【核心差异对比】")
    print("-"*70)
    print(f"  对比维度         铅钡玻璃            高钾玻璃")
    print("-"*70)
    print(f"  核心敏感成分      PbO、BaO            K₂O")
    print(f"  流失幅度          PbO {pb_diff:+.2f}%          K₂O {k_diff:+.2f}%")
    print(f"  流失机理          重金属离子溶出       酸性土壤离子交换")
    print(f"  SiO₂富集幅度     +{results['铅钡'][results['铅钡']['氧化物']=='二氧化硅(SiO2)']['差值(风化-无风化)'].values[0]:.2f}%     +{results['高钾'][results['高钾']['氧化物']=='二氧化硅(SiO2)']['差值(风化-无风化)'].values[0]:.2f}%")
    print(f"  判别阈值参考      PbO<30%+BaO<10%     K₂O<7%")
    print("-"*70)

# ====================== 6. 风化前成分预测 ======================
print("\\n" + "="*70)
print("5.2.4 风化前成分预测")
print("="*70)

# 解析配对数据
pair_diffs = []
for idx, row in df_pairs.iterrows():
    weathered = np.array(eval(row['风化成分']))
    original = np.array(eval(row['原始未风化成分']))
    diff = original - weathered
    pair_diffs.append(diff)
    print(f"\\n文物{row['文物编号']} 配对差值：")
    for i, col in enumerate(component_cols):
        if abs(diff[i]) > 0.1:
            print(f"  {short_names[i]}: {diff[i]:+.2f}%")

df_diffs = pd.DataFrame(pair_diffs, columns=component_cols)

# 计算铅钡玻璃差值均值（两组都是铅钡）
pb_diff_means = df_diffs.mean()
print(f"\\n铅钡玻璃配对差值均值（用于预测）：")
for i, col in enumerate(component_cols):
    if abs(pb_diff_means[col]) > 0.1:
        print(f"  {short_names[i]}: {pb_diff_means[col]:+.2f}%")

# 高钾玻璃差值来自统计规律
k_diff_from_stats = results['高钾'][results['高钾']['氧化物'] == '氧化钾(K2O)']['差值(风化-无风化)'].values[0]
print(f"\\n高钾玻璃差值基准（来自5.2.2统计规律）：")
print(f"  K₂O: {k_diff_from_stats:+.2f}%")

# 预测每个风化样本
predictions = []
for idx, row in df_weathered.iterrows():
    glass_type = row['类型']
    if glass_type == '铅钡':
        delta = pb_diff_means
    else:  # 高钾
        delta = pd.Series(0.0, index=component_cols, dtype="float64")
        delta['氧化钾(K2O)'] = -k_diff_from_stats  # 反向校正
    
    weathered_comp = row[component_cols].values
    original_pred = weathered_comp + delta.values
    
    # 二次归一化
    pred_sum = original_pred.sum()
    if pred_sum > 0:
        original_pred = original_pred / pred_sum * 100
    
    predictions.append({
        '文物编号': row['文物编号'],
        '采样点': row['文物采样点'],
        '类型': glass_type,
        '风化等级': row['风化等级'],
        **{f'预测_{col}': val for col, val in zip(component_cols, original_pred)}
    })

df_predictions = pd.DataFrame(predictions)
print(f"\\n已预测 {len(df_predictions)} 个风化样本的原始成分")
print(f"  铅钡玻璃: {len(df_predictions[df_predictions['类型']=='铅钡'])} 个")
print(f"  高钾玻璃: {len(df_predictions[df_predictions['类型']=='高钾'])} 个")

# 保存预测结果
df_predictions.to_csv('风化前成分预测结果.csv', index=False, encoding='utf-8-sig')
print("\\n预测结果已保存至：风化前成分预测结果.csv")

# ====================== 7. 可视化 ======================
print("\\n" + "="*70)
print("生成可视化图表")
print("="*70)

# 7.1 关键氧化物风化/无风化对比箱线图（按类型分面）
key_cols = ['二氧化硅(SiO2)', '氧化铅(PbO)', '氧化钾(K2O)', '氧化钡(BaO)', '氧化钙(CaO)', '氧化铝(Al2O3)']
key_labels = ['SiO₂', 'PbO', 'K₂O', 'BaO', 'CaO', 'Al₂O₃']

fig, axes = plt.subplots(2, 3, figsize=(15, 10))
axes = axes.flatten()

for idx, col in enumerate(key_cols):
    ax = axes[idx]
    data_list, label_list, color_list = [], [], []
    
    for glass_type in df_all['类型'].unique():
        no_w = df_no_weather[df_no_weather['类型'] == glass_type][col].dropna()
        w = df_weathered[df_weathered['类型'] == glass_type][col].dropna()
        
        if len(no_w) > 0:
            data_list.append(no_w)
            label_list.append(f'{glass_type}\\n无风化')
            color_list.append('#2ecc71')
        if len(w) > 0:
            data_list.append(w)
            label_list.append(f'{glass_type}\\n风化')
            color_list.append('#e74c3c')
    
    if data_list:
        bp = ax.boxplot(data_list, labels=label_list, patch_artist=True)
        for patch, color in zip(bp['boxes'], color_list):
            patch.set_facecolor(color)
            patch.set_alpha(0.7)
        ax.set_title(key_labels[idx], fontsize=12)
        ax.set_ylabel('含量(%)', fontsize=10)
        ax.grid(axis='y', linestyle='--', alpha=0.3)
        ax.tick_params(axis='x', labelsize=8)

plt.suptitle('不同玻璃类型中关键氧化物风化/无风化含量对比', fontsize=16, fontweight='bold')
plt.tight_layout()
plt.savefig('5-3_风化成分对比箱线图.png', dpi=300, bbox_inches='tight')
print("已保存：5-3_风化成分对比箱线图.png")

# 7.2 风化前成分预测对比图
fig, axes = plt.subplots(2, 3, figsize=(15, 10))
axes = axes.flatten()

for idx, col in enumerate(key_cols[:6]):
    ax = axes[idx]
    glass_type = '铅钡'
    
    w_vals = df_weathered[df_weathered['类型']==glass_type][col].values
    pred_vals = df_predictions[df_predictions['类型']==glass_type][f'预测_{col}'].values
    ref_vals = df_no_weather[df_no_weather['类型']==glass_type][col].values
    
    if len(w_vals) > 0 and len(pred_vals) > 0:
        x = np.arange(len(w_vals))
        ax.scatter(x, w_vals, label='风化后(实际)', color='red', s=50, marker='o', alpha=0.7)
        ax.scatter(x, pred_vals, label='预测原始', color='blue', s=50, marker='s', alpha=0.7)
        if len(ref_vals) > 0:
            ax.axhline(y=np.mean(ref_vals), color='green', linestyle='--', 
                      label=f'未风化参考均值={np.mean(ref_vals):.1f}', alpha=0.7)
        ax.set_title(f'{key_labels[idx]} (铅钡玻璃)', fontsize=12)
        ax.set_ylabel('含量(%)', fontsize=10)
        ax.legend(fontsize=8)
        ax.grid(axis='y', linestyle='--', alpha=0.3)

plt.suptitle('铅钡玻璃风化样本预测原始成分 vs 实际风化成分', fontsize=16, fontweight='bold')
plt.tight_layout()
plt.savefig('5-4_风化前成分预测对比图.png', dpi=300, bbox_inches='tight')
print("已保存：5-4_风化前成分预测对比图.png")

# 7.3 差值热力图
fig, ax = plt.subplots(figsize=(12, 4))
diff_matrix = np.array([pb_diff_means.values])
im = ax.imshow(diff_matrix, cmap='RdBu_r', aspect='auto', vmin=-6, vmax=6)
ax.set_xticks(range(len(component_cols)))
ax.set_xticklabels(short_names, rotation=45, ha='right', fontsize=10)
ax.set_yticks([0])
ax.set_yticklabels(['铅钡玻璃\\n差值均值'], fontsize=11)
ax.set_title('铅钡玻璃风化前后各氧化物差值均值\\n(红色=风化流失，蓝色=风化富集)', fontsize=14)
for j, val in enumerate(pb_diff_means.values):
    ax.text(j, 0, f'{val:.1f}', ha='center', va='center', fontsize=10,
           color='white' if abs(val) > 3 else 'black')
plt.colorbar(im, ax=ax, label='差值 (百分点)')
plt.tight_layout()
plt.savefig('5-5_风化差值热力图.png', dpi=300, bbox_inches='tight')
print("已保存：5-5_风化差值热力图.png")

# ====================== 8. 输出论文表格数据 ======================
print("\\n" + "="*70)
print("论文表格数据（可直接复制）")
print("="*70)

for glass_type, df_stats in results.items():
    print(f"\\n【表5-{1 if glass_type=='铅钡' else 2} {glass_type}玻璃风化/无风化成分统计对比】")
    print("-"*90)
    # 【改】表头用 Cohen_d
    print(f"| {'氧化物':<10} | {'无风化均值(%)':>12} | {'风化均值(%)':>12} | {'差值(百分点)':>12} | {'p值':>10} | {'显著性':>6} | {'Cohen_d':>10} | {'效应量':>6} | {'变化机理':<12} |")
    print("-"*90)
    for _, row in df_stats.iterrows():
        # 【改】数据行用 row['Cohen_d']
        print(f"| {row['简称']:<10} | {row['无风化_均值']:>12.2f} | {row['风化_均值']:>12.2f} | {row['差值(风化-无风化)']:>12.2f} | {row['p值']:>10.4f} | {row['显著性']:>6} | {row['Cohen_d']:>10.2f} | {row['效应量']:>6} | {row['变化机理']:<12} |")
    print("-"*90)

print("\\n" + "="*70)
print("分析完成！")
print("="*70)